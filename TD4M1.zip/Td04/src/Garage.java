import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Garage{
	private List<Car>voitures;
	private static int id;
	private List<Bike>V�los;
	
	public Garage() {
		    this.voitures = new ArrayList<Car>();
		    id++;
	}
	/*public void add(Car voiture) {
		Objects.requireNonNull(voiture, "voiture must not be null");
		voitures.add(voiture);
	}*/
	
	public void add(Object obj) {
		if (obj instanceof Car){
			Car voiture = (Car) obj;
			Objects.requireNonNull(voiture, "voiture must not be null");
			voitures.add((Car)voiture);
		}else{
			Bike b1 = (Bike) obj;
			V�los.add((Bike)b1);
		}
	}
	public int getId() {
		return id;
	}
	public String toString(){
	    StringBuilder sb = new StringBuilder();
	    for(Car cetteVoiture :voitures) {
	    	sb.append(cetteVoiture);
	    }
	    String result = sb.toString();
	    return result;
	}
	public int ValeurGarage() {
		int somme=0;
		for(Car voiture :voitures) {
			somme+=voiture.getValue();
		}
		return somme;
	}
	public Car firstCarByBrand(String brand) {
		for(Car  cetteVoiture :voitures) {
			if(cetteVoiture.getBrand1().equals(brand)) {
				return cetteVoiture;
			}
		}
		return null;
	}
	public void remove(Car voiture) {
		for(Car  uneVoiture :voitures) {
			if(uneVoiture.equals(voiture)) {
				voitures.remove(uneVoiture);
			}
		}
	}
}
