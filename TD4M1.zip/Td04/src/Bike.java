
public class Bike {
	String marque;
	final int valeur;
	public Bike(String marque) {
		this.marque = marque;
		this.valeur=100;
	}
	
	
}
