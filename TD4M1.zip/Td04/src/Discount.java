
public class Discount {
	int value;

	public Discount(int value) {

		this.value = value;
	}
	
}
