
public class Car {
	private final String brand1;
	private final String brand2;
	private long value;
	private int vetuste;
	//Constructeur
	public Car(String brand1,long value) {
		if(value<=0) {
			System.out.println("impossible de cr�er une voiture de valeur n�gative ressayer une autre fois");
		}
		else {
			this.value = value;
		}
			
		this.brand1 = "b1";
		this.brand2 = "b2";
	}
	//Constructeur
	public Car(int vetuste) {
		this.brand1 = "";
		this.brand2 = "";
		this.vetuste = vetuste;
	}
	
	public int valeurVetuste(int vetuste,long value) {
		int valeur;
			 valeur = vetuste*1000-(int)value;
			 return valeur;
		
	}
	
	//Acceseurs
	public String getBrand1() {
		return brand1;
	}

	public String getBrand2() {
		return brand2;
	}

	public long getValue() {
		return value;
	}
	public void setValue(long value) {
		this.value = value;
	}
	
	public String toString() {
		return brand1+" "+brand2+" "+value;
	}
	
	
	public boolean equals(Car c) {
			if((this.brand1==c.brand1)&&(this.brand2==c.brand2)&&(this.value==c.value)) {
				return true;
			}
		
		return false;
	}
	
}
